export const Span = ({SpanID})=>{
    return(
        <span id="error-message">
            Введите номер в правильном формате например
        </span>
    )
}